﻿using System;
using System.Globalization;
namespace Exe_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vendedor vendedor = new Vendedor();

            Console.Write("Nome do vendedor: ");

            vendedor.nome = Console.ReadLine();

            Console.Write("Salário fixo: R$ ");
            vendedor.salarioFixo = double.Parse(Console.ReadLine());

            Console.Write("Total de vendas efetuadas: R$ ");
            vendedor.vendasEfetuadas = double.Parse(Console.ReadLine());

            double salarioTotal = vendedor.CalcularSalario();

            Console.WriteLine("O vendedor {0} receberá R$ {1:F2} este mês", vendedor.nome, salarioTotal);
        }
    }
}
