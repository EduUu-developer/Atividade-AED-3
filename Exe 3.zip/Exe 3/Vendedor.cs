﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe_3
{
    internal class Vendedor
    {
        public string nome;
        public double salarioFixo;
        public double vendasEfetuadas;

        public double CalcularSalario()
        {
            double comissao = vendasEfetuadas * 0.15;
            double salarioTotal = salarioFixo + comissao;
            return salarioTotal;
        }
    }
}
