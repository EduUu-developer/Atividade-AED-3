﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o valor de A: ");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor de B: ");
            double b = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor de C: ");
            double c = double.Parse(Console.ReadLine());

            Triangulo triangulo = new Triangulo(a, b, c);

            triangulo.VerificaTipoTriangulo();
        }
    }

}
