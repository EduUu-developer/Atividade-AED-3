﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe4
{
    internal class Triangulo
    {
        
    private double a, b, c;

        public Triangulo(double a, double b, double c)
        {
            if (a <= 0 || b <= 0 || c <= 0)
            {
                Console.WriteLine("Erro: os valores devem ser maiores do que zero!");
                Console.WriteLine("Digite um novo valor para A: ");
                a = double.Parse(Console.ReadLine());
                Console.WriteLine("Digite um novo valor para B: ");
                b = double.Parse(Console.ReadLine());
                Console.WriteLine("Digite um novo valor para C: ");
                c = double.Parse(Console.ReadLine());
            }

            this.a = a;
            this.b = b;
            this.c = c;
        }

        public void VerificaTipoTriangulo()
        {
            if (a >= b + c)
            {
                Console.WriteLine("NAO FORMA TRIANGULO");
            }
            else
            {
                if (Math.Pow(a, 2) == Math.Pow(b, 2) + Math.Pow(c, 2))
                {
                    Console.WriteLine("TRIANGULO RETANGULO");
                }

                if (Math.Pow(a, 2) > Math.Pow(b, 2) + Math.Pow(c, 2))
                {
                    Console.WriteLine("TRIANGULO OBTUSANGULO");
                }

                if (Math.Pow(a, 2) < Math.Pow(b, 2) + Math.Pow(c, 2))
                {
                    Console.WriteLine("TRIANGULO ACUTANGULO");
                }

                if (a == b && b == c)
                {
                    Console.WriteLine("TRIANGULO EQUILATERO");
                }

                if ((a == b && a != c) || (a == c && a != b) || (b == c && b != a))
                {
                    Console.WriteLine("TRIANGULO ISOSCELES");
                }
            }
        }
    }

}
